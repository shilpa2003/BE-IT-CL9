import java.rmi.*;
import java.rmi.server.*;
import java.lang.Math;

public class AdderRemote extends UnicastRemoteObject implements Adder{

AdderRemote()throws RemoteException{
super();
}

public int add(int x,int y){return x+y;}
public int sub(int x,int y){return x-y;}
public int mul(int x,int y){return x*y;}
public int div(int x,int y){return x/y;}
public int pow(int x,int y){return (int)Math.pow(x,y);}

}
