import java.rmi.*;
import java.util.Scanner;
import java.io.*;

public class MyClient{

public static void main(String args[]){
try{

Adder stub=(Adder)Naming.lookup("rmi://localhost:5000/sonoo");
Scanner sc = new Scanner(System.in);
System.out.println("Enter the two numbers:");
			int a = sc.nextInt();
			int b = sc.nextInt();
			System.out.println("Addition is "+stub.add(a, b));
			System.out.println("Multiplication is "+stub.mul(a, b));
			System.out.println("Subtaction is "+stub.sub(a, b));
			System.out.println("Division is "+stub.div(a, b));
			System.out.println("Pow is "+stub.pow(a, b));



}catch(Exception e){System.out.println(e);}
}

}
