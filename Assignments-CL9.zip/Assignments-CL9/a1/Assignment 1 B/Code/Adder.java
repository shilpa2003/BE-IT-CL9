import java.rmi.*;
public interface Adder extends Remote{

 public int add (int d1, int d2) throws RemoteException;
    public int sub (int d1, int d2) throws RemoteException;
   public int mul (int d1, int d2) throws RemoteException;
   public int div (int d1, int d2) throws RemoteException;
   public int pow(int d1, int d2) throws RemoteException;
}
