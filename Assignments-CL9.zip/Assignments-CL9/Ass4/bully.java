import java.io.*;
import java.util.*;
public class bully{
static int tot_process=6;
static boolean state[]=new boolean[tot_process];
static int coordinator=0;

public static void up(int pid){
state[pid]=true;
elect(pid);
}

public static void down(int pid){
state[pid]=false;
}

public static void elect(int pid){
 int i=pid;
 int j=i+1;
 int tempCord=pid;
 for(i=pid;i<tot_process;i++){
 	for(j=i+1;j<tot_process;j++){
 		if(state[j]==true){
 			System.out.println("Message send from "+i+" to "+j);
 		}
 	}
 	for(j=i+1;j<tot_process;j++){
 		if(state[i]==true && state[j]==true){
 			System.out.println("process "+j+" sends ok ");
 			tempCord=j;
 		}
 	}
 }
 coordinator=tempCord;
}
public static void main(String args[]){
	for(int i=0;i<bully.tot_process;i++){
		bully.state[i]=true;
		System.out.println("Process "+i+" is up");
	}
	bully.coordinator=5;
	bully.down(5);
	System.out.println(bully.coordinator);
	bully.down(2);
	bully.up(2);
	System.out.println(bully.coordinator);
	bully.elect(1);
	System.out.println(bully.coordinator);
	
	
}
};
