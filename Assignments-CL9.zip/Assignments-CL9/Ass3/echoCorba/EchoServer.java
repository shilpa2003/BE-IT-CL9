import EchoApp.EchoPOA;

public class EchoServer extends EchoPOA {
    @Override
    public String echoString() {
        return "Hello World!!!!!!!";
    }
}