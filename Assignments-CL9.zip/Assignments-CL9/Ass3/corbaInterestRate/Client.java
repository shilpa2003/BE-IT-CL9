import InterestRateApp.InterestRate;
import InterestRateApp.InterestRateHelper;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

public class Client {

    public static void main(String args[]) {
        try {
            // create and initialize the ORB
            ORB orb = ORB.init(args, null);
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            InterestRate href = InterestRateHelper.narrow(ncRef.resolve_str("ECHO-SERVER"));

            //float a = href.getHomeLoan();
            System.out.println("");
            System.out.println("Interest Rates Provided By YS Industry:");
            System.out.println("Home Loan Interest:"+href.getHomeLoan()+"%");
            System.out.println("CAR Loan Interest:"+href.getCarLoan()+"%");
            System.out.println("GOLD Loan Interest:"+href.getGoldLoan()+"%");
        } catch (InvalidName invalidName) {
            invalidName.printStackTrace();
        } catch (CannotProceed cannotProceed) {
            cannotProceed.printStackTrace();
        } catch (org.omg.CosNaming.NamingContextPackage.InvalidName invalidName) {
            invalidName.printStackTrace();
        } catch (NotFound notFound) {
            notFound.printStackTrace();
        }

    }

}