import InterestRateApp.InterestRatePOA;
public class EchoServer extends InterestRatePOA {
    @Override
    public float getHomeLoan() {return 0.25f;}
	public float getCarLoan() {return 0.54f;}
	public float getGoldLoan() {return 0.33f;}
}