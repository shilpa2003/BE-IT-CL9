package pubsub;
/*
import javax.jms.*;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class Publisher {
	private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;

	public static void main(String[] args) throws JMSException {
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
		Connection connection = connectionFactory.createConnection();
		connection.start();
// JMS messages are sent and received using a Session. We will
// create here a non-transactional session object. If you want
// to use transactions you should set the first parameter to 'true'
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Topic topic = session.createTopic("CL9");
		MessageProducer producer = session.createProducer(topic);
// We will send a small text message saying 'Hello'
		TextMessage message = session.createTextMessage();
		message.setText("This is a new message from publisher");
// Here we are sending the message!
		producer.send(message);
		System.out.println("Sent message '" + message.getText() + "'");
		connection.close();
	}
}*/
//import com.google.gson.Gson;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
class StockEvent{
	static int id =1;
	static String name ="yash";
	
	public static String getData() {
		return "id :"+id+" Name : "+name;
		
	}
};
public class Publisher{

    private static String ACTIVE_MQ_URL = ActiveMQConnection.DEFAULT_BROKER_URL;

    public static void main(String[] args) {
        try {
            System.out.println("Publisher");
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(ACTIVE_MQ_URL);
            Connection connection = connectionFactory.createConnection();
            connection.start();
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Topic topic = session.createTopic("Stock");
            MessageProducer producer = session.createProducer(topic);
            TextMessage message = session.createTextMessage();
            message.setText(StockEvent.getData());
            producer.send(message);
            System.out.println("Sent message " + message.getText());
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}